$(function() {
	/*动态控制右侧高度*/
	var h1=$(".hyh-box-right").height();
	var h2=$(".hyh-box-left").height();
	if(h2>h1){
		$(".hyh-box-right").height(h2);
	}
})